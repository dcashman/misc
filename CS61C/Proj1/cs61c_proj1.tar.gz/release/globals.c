#include "common.h"
#include "globals.h"

room_t *room_array;

int num_rooms;

player_t the_player;
