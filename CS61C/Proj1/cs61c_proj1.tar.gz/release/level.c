#include "level.h"
#include "common.h"
#include "util.h"

// array of directio names. must be consistent with the order of the enum
// in level.h
char *direction_names[] = {
    "north",
    "south",
    "east",
    "west",
    "up",
    "down"
};


// loads a level from a config file and returns a pointer to the starting room
room_t *load_level(char *filename) {
    char buf[2048];
    char *whitespace = " \t\n";
    FILE *levelfile = fopen(filename,"r");

    if(levelfile == NULL) {
        printf("Could not open %s\n", filename);
        exit(1);
    }

    skip_characters(levelfile, whitespace);
    
    // get the total number of rooms
    fgets(buf,256,levelfile);
    num_rooms = atoi(buf);

    skip_characters(levelfile, whitespace);

    // allocate an array for all of the room structs to be stored
	// store the pointer in the global room_array variable
	/*** YOUR CODE HERE ***/

    // Initialize room_array
	/*** YOUR CODE HERE ***/

    skip_characters(levelfile, whitespace);

	// one line at a time, read in room description strings and set 
	// the appropriate field in each string's corresponding room struct
    while(fgets(buf, 256, levelfile), buf[0] != '\n') {
		/*** YOUR CODE HERE ***/
    }

    skip_characters(levelfile, whitespace);

	// hook up rooms so that exits point to each other appropriately.
	// exits should also be set to locked or unlocked as necessary
    while(fgets(buf, 256, levelfile), buf[0] != '\n' && !feof(levelfile)) {
        char *words[32];
        tokenizer(buf, words, " \t\n");
        
		assert(!strcmp("can-go", words[0]) || !strcmp("cant-go", words[0]));
        
		direction dir;
        switch(words[1][0]) {
            case 'n':
                dir = NORTH;
                break;
            case 's':
                dir = SOUTH;
                break;
            case 'e':
                dir = EAST;
                break;
            case 'w':
                dir = WEST;
                break;
            case 'u':
                dir = UP;
                break;
            case 'd':
                dir = DOWN;
                break;
            default:
                printf("%s isn't a direction\n", words[1]);
                assert(false);
        }
		
		/*** YOUR CODE HERE ***/
    }

    return room_array; // equivalent to a pointer to the first element of the array
}

