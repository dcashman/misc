#ifndef PUZZLES_H
#define PUZZLES_H

#include "commands.h"

cmd_fxn_t get_puzzle_description(int idx);
cmd_fxn_t get_puzzle_solver(int idx);

void i_love_additional_status_its_so_bad(void);

#endif
